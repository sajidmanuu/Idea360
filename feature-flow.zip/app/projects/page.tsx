import ProjectList from '@/components/Dashboard/projects'
import DefaultLayout from '@/components/Layouts/DefaultLayout'
import { NextPage } from 'next'
const Page: NextPage = () => {
  return <div>
   <DefaultLayout>
     <ProjectList />
    </DefaultLayout>
  </div>
}

export default Page